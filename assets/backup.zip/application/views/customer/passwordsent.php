<div class="container" style="margin-top:100px;margin-bottom:100px;">
    <div class="row">
        <div class="span8 offset2">
            <center>
            <h3>Your password has been sent to your email.</h3>
            <h3>Thank you.</h3>
            </center>
        </div>
    </div>
</div>
