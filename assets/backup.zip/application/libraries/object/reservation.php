<?php 
/**
 * This file defines the class Reservation, it maps the PACKAGE database.
 *
 * @author  Xinyun Zhou <me@xyzhou.com>
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * This class defines the behaviours for Reservation specifically
 *
class Reservation extends Object
{
    /*
     * Default constructor from parent, load query table.
     *
    function __construct() {
        parent::__construct();
        $this->query_table = 'reservation';
    }
}*/
