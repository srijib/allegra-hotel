<?php if (!defined('BASEPATH')) die();

class ContactusPage extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

	public function index()
	{
        $option = new Opt();
        $contactus_content = array(
            array(
                'Telephone', 'Fax', 'Postal address'
                ),
            array(
                $option->get('contactus_phone'), $option->get('contactus_fax'), $option->get('contactus_postal')
                )
        );

        $data['contactus_content'] = $contactus_content;
		$data['title'] = 'Contact Us';
		$this->load->view('include/header', $data);
		$this->load->view('contactuspage');
		$this->load->view('include/footer');
	}
}