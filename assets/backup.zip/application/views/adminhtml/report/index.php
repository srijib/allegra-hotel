<div class="row">
    <div class="span12">
        <div class="btn-group">
            <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" href="#">
                Reservations
                <span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
                <li><a href="#">All Current Month Reservations</a></li>
            </ul>
        </div>
        <div class="btn-group">
            <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" href="#">
                Packages
                <span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
                <li><li><a href="#">All Packages</a></li></li>
            </ul>
        </div>
        <div class="btn-group">
            <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" href="#">
                Customers
                <span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
                <li><li><a href="#">Customers on email list</a></li></li>
            </ul>
        </div>
    </div>
</div>