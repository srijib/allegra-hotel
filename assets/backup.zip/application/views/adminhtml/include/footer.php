    <div class="container">
        <div class="row">
            <div class="span12 footer hotel_footer">
                <p>&copy;<strong>Allegra Hotels</strong>. All rights reserved.</p>
                <p>Developed and maintained by techTurbo.</p>
            </div>
        </div>
    </div>
</body>
</html>
