<div class="container">
    <div class="row">
        <div class="span12">
            <h3>Welcome!</h3>
        </div>
    </div>
</div>