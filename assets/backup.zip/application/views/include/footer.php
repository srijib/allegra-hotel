    <div class="row">
        <div class="span12 footer hotel_footer">
            <hr>
            <p>&copy;<strong>Allegra Hotels</strong>. All rights reserved.</p>
            <p>
                Developed and maintained by techTurbo.
                <img src="<?php echo base_url('assets/img/techTurbo_logo4.png')?>" alt="techTurbo">
            </p>
        </div>
    </div>
</div>

</body>
</html>
